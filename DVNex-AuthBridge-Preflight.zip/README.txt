DVNex AuthBridge - Preflight

Este pacote e somente leitura. Nao modifica o APK, Manifest, DEX ou Smali.

Collision-Public-API-Comparison.csv compara os metodos publicos/protegidos declarados nas classes existentes do DVNex com os metodos da mesma classe nos artefatos de dependencia usados pelo AuthBridge.

Importante: igualdade de metodos publicos NAO prova igualdade binaria ou equivalencia de comportamento. Campos, superclasses, interfaces, anotacoes, recursos e implementacao interna nao sao comparados neste relatorio.

AAR-Resources-and-Manifests.csv lista a presenca de manifestos e os caminhos de recursos de cada AAR. Os manifestos encontrados foram copiados para aar-manifests/.

Nenhum APK foi criado nesta etapa.